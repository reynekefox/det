# Adding classification logging with model info to include which DeepSeek model is responding.
import os
import asyncio
import logging
import re
from datetime import datetime, timedelta
import requests

logger = logging.getLogger(__name__)

async def send_long_message_safe(message, text: str, parse_mode: str = None, chunk_size: int = 3500):
    """Безопасная отправка длинных сообщений с разбивкой на части"""
    # Telegram лимит 4096 символов, оставляем запас
    max_telegram_length = 4000
    
    if len(text) <= max_telegram_length:
        try:
            await message.answer(text, parse_mode=parse_mode)
        except Exception as e:
            logger.error(f"Ошибка при отправке короткого сообщения: {e}")
            try:
                await message.answer(text)  # Попробуем без parse_mode
            except Exception as e2:
                logger.error(f"Критическая ошибка отправки: {e2}")
        return

    logger.info(f"📤 Разбиваем длинное сообщение ({len(text)} символов) на части")

    # Разбиваем на части с учетом границ предложений
    chunks = []
    current_pos = 0

    while current_pos < len(text):
        # Определяем границу чанка
        end_pos = min(current_pos + chunk_size, len(text))

        # Если это не последний чанк, ищем лучшее место для разбивки
        if end_pos < len(text):
            # Ищем ближайший конец предложения в последних 800 символах чанка
            search_start = max(end_pos - 800, current_pos + 500)  # Минимум 500 символов в чанке
            best_break = end_pos

            # Сначала ищем конец абзаца (двойной перенос строки)
            for i in range(end_pos - 1, search_start - 1, -1):
                if i + 1 < len(text) and text[i:i+2] == '\n\n':
                    best_break = i + 2
                    break

            # Если не нашли конец абзаца, ищем точку, восклицательный или вопросительный знак
            if best_break == end_pos:
                for i in range(end_pos - 1, search_start - 1, -1):
                    if text[i] in '.!?' and (i + 1 >= len(text) or text[i + 1] in ' \n\t'):
                        best_break = i + 1
                        break

            # Если не нашли конец предложения, ищем одинарный перенос строки
            if best_break == end_pos:
                for i in range(end_pos - 1, search_start - 1, -1):
                    if text[i] == '\n':
                        best_break = i + 1
                        break

            # В крайнем случае ищем ближайший пробел
            if best_break == end_pos:
                for i in range(end_pos - 200, search_start - 1, -1):
                    if text[i] == ' ':
                        best_break = i + 1
                        break

            end_pos = best_break

        chunk_data = text[current_pos:end_pos].strip()

        # Проверяем длину финального чанка и обрезаем если нужно
        if len(chunk_data) > max_telegram_length:
            chunk_data = chunk_data[:max_telegram_length - 50] + "\n\n[...]"

        if chunk_data:  # Отправляем только непустые чанки
            chunks.append(chunk_data)
            logger.info(f"📦 Создан чанк {len(chunks)}: {len(chunk_data)} символов")

        current_pos = end_pos

    logger.info(f"📋 Всего создано чанков: {len(chunks)}")

    # Отправляем чанки
    for i, chunk in enumerate(chunks):
        try:
            logger.info(f"📤 Отправляем чанк {i+1}/{len(chunks)} ({len(chunk)} символов)")
            await message.answer(chunk, parse_mode=parse_mode)
            await asyncio.sleep(0.2)  # Небольшая задержка между сообщениями
        except Exception as e:
            logger.error(f"Ошибка при отправке чанка {i+1} с HTML: {e}")
            try:
                await message.answer(chunk)  # Попробуем без parse_mode
                await asyncio.sleep(0.2)
            except Exception as e2:
                logger.error(f"Критическая ошибка при отправке чанка {i+1}: {e2}")

_api_key = None

def format_markdown_to_html(text):
    try:
        # Сначала экранируем HTML-символы
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;').replace('>', '&gt;')

        # Обрабатываем markdown-разметку
        # Жирный текст (**text**)
        text = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', text)

        # Курсив (*text*) - только если не часть жирного текста
        text = re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)', r'<i>\1</i>', text)

        # Инлайн код (`code`)
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

        # Ссылки [text](url)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

        # Заголовки (# ## ###)
        text = re.sub(r'^(#{1,3})\s+(.+)$', r'<b>\2</b>', text, flags=re.MULTILINE)

        # Возвращаем обратно HTML-символы там, где нужно
        text = text.replace('&lt;b&gt;', '<b>').replace('&lt;/b&gt;', '</b>')
        text = text.replace('&lt;i&gt;', '<i>').replace('&lt;/i&gt;', '</i>')
        text = text.replace('&lt;code&gt;', '<code>').replace('&lt;/code&gt;', '</code>')
        text = text.replace('&lt;a href=', '<a href=').replace('&gt;', '>', 1)

        return text
    except Exception as e:
        logger.error(f"Ошибка форматирования markdown: {e}")
        return text

dialogs = {}

async def classify_question_complexity(message, dialog_history):
    """Классифицирует сложность вопроса для выбора модели DeepSeek"""
    complexity_system_prompt = (
        "Классифицируй сложность вопроса. Ответь ТОЛЬКО одним словом: ПРОСТОЙ или СЛОЖНЫЙ. "
        "ПРОСТОЙ: сказки, игры, базовые советы, простые рекомендации. "
        "СЛОЖНЫЙ: анализ поведения, комплексные проблемы, детальные планы. "
        "ВАЖНО: отвечай ТОЛЬКО одним словом!"
    )

    # Берем только последнее сообщение пользователя для классификации
    temp_messages = [{"role": "user", "content": message.text}]

    try:
        complexity_result = await handle_deepseek_message(
            message=message,
            system_prompt_content=complexity_system_prompt,
            sheets_logger_instance=None,
            is_complexity_classification=True,
            dialog_history_override=temp_messages,
            max_tokens_override=5
        )

        # Извлекаем только первое слово из ответа
        first_word = complexity_result.strip().split()[0].upper()

        if "ПРОСТОЙ" in first_word or "SIMPLE" in first_word:
            complexity = "ПРОСТОЙ"
        elif "СЛОЖНЫЙ" in first_word or "COMPLEX" in first_word:
            complexity = "СЛОЖНЫЙ"
        else:
            # Если классификация неясна, анализируем ключевые слова в вопросе
            question_lower = message.text.lower()
            simple_keywords = ["сказк", "игр", "совет", "что делать", "как", "расскаж"]
            complex_keywords = ["анализ", "стратеги", "план", "причин", "проблем", "индивидуальн"]

            if any(keyword in question_lower for keyword in simple_keywords):
                complexity = "ПРОСТОЙ"
            elif any(keyword in question_lower for keyword in complex_keywords):
                complexity = "СЛОЖНЫЙ"
            else:
                complexity = "ПРОСТОЙ"  # По умолчанию простой для быстрых ответов

        return complexity

    except Exception as e:
        return "ПРОСТОЙ"  # Изменено на ПРОСТОЙ для более быстрых ответов

def add_message_to_deepseek_dialog(user_id: int, role: str, content: str):
    if user_id not in dialogs:
        dialogs[user_id] = {"messages": [], "updated": datetime.now()}

    dialogs[user_id]["messages"].append({"role": role, "content": content})
    dialogs[user_id]["updated"] = datetime.now()

def clear_user_dialog(user_id):
    if user_id in dialogs:
        dialogs[user_id]["messages"].clear()
        dialogs[user_id]["updated"] = datetime.now()
        return True
    return False

async def handle_deepseek_message(
    message,
    system_prompt_content: str,
    sheets_logger_instance=None,
    is_classification_request: bool = False,
    dialog_history_override: list = None,
    max_tokens_override: int = None,
    is_complexity_classification: bool = False
):
    global _api_key

    if _api_key is None:
        _api_key = os.getenv("DEEPSEEK_API_KEY")
        if not _api_key:
            logger.critical("DEEPSEEK_API_KEY не установлен в переменных окружения!")
            if not is_classification_request:
                await message.answer("Извините, внутренняя ошибка конфигурации. Ключ API для DeepSeek не найден.")
            return ""

    uid = message.from_user.id
    now = datetime.now()

    # Всегда используем reasoning модель
    if is_classification_request or is_complexity_classification:
        model_to_use = "deepseek-chat"  # Для классификации используем быструю модель
    else:
        model_to_use = "deepseek-reasoner"  # Для всех основных запросов используем reasoning
        print(f"🧠 Используется модель '{model_to_use}' (reasoning) для ответа")

    # Добавляем информацию о пользователе в системный промпт (если это не классификация)
    if not is_classification_request and not is_complexity_classification:
        user_name = message.from_user.full_name or message.from_user.first_name or f"пользователь"
        user_info = f"\n\nИнформация о пользователе: Зовут {user_name}. Обращайтесь к пользователю по имени в своих ответах."
        system_prompt_with_user = system_prompt_content + user_info
    else:
        system_prompt_with_user = system_prompt_content

    if (is_classification_request or is_complexity_classification) and dialog_history_override:
        messages_for_api = [
            {"role": "system", "content": system_prompt_with_user}
        ] + dialog_history_override
    else:
        dlg = dialogs.get(uid, {"messages": [], "updated": now})
        if now - dlg.get("updated", now) > timedelta(hours=48):
            dlg["messages"].clear()

        dlg["messages"].append({"role": "user", "content": message.text})
        dlg["updated"] = now
        dialogs[uid] = dlg

        messages_for_api = [
            {"role": "system", "content": system_prompt_with_user}
        ] + dlg["messages"]

    try:
        max_tokens_to_use = max_tokens_override if max_tokens_override is not None else 2000
        max_retries = 3
        base_timeout = 90

        for attempt in range(max_retries):
            try:
                current_timeout = base_timeout * (attempt + 1)
                response = requests.post(
                    "https://api.deepseek.com/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {_api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": model_to_use,
                        "messages": messages_for_api,
                        "temperature": 0.0 if (is_classification_request or is_complexity_classification) else 0.7,
                        "max_tokens": max_tokens_to_use
                    },
                    timeout=current_timeout
                )

                response.raise_for_status()

                data = response.json()
                answer = data["choices"][0]["message"]["content"].strip()

                if not (is_classification_request or is_complexity_classification):
                    dlg["messages"].append({"role": "assistant", "content": answer})
                    formatted_answer = format_markdown_to_html(answer)
                    await send_long_message_safe(message, formatted_answer, parse_mode='HTML')

                    if sheets_logger_instance:
                        user_name = message.from_user.full_name or f"User_{message.from_user.id}"
                        user_id = message.from_user.id
                        sheets_logger_instance.log_message(user_name, user_id, answer, is_user=False)

                if is_complexity_classification:
                    return answer.strip().upper()
                else:
                    return answer

            except requests.exceptions.Timeout:
                if attempt == max_retries - 1:
                    if not is_classification_request:
                        await message.answer(f"Извините, запрос к AI занял слишком много времени. Попробуйте позже.")
                else:
                    await asyncio.sleep(2)
                    continue
            except requests.exceptions.RequestException as e:
                # Если ошибка 400 с моделью R1, попробуем обычную модель
                if "400" in str(e) and attempt == 0:
                    try:
                        response = requests.post(
                            "https://api.deepseek.com/v1/chat/completions",
                            headers={
                                "Authorization": f"Bearer {_api_key}",
                                "Content-Type": "application/json"
                            },
                            json={
                                "model": "deepseek-chat",
                                "messages": messages_for_api,
                                "temperature": 0.0 if is_classification_request else 0.7,
                                "max_tokens": max_tokens_to_use
                            },
                            timeout=current_timeout
                        )
                        response.raise_for_status()
                        data = response.json()
                        answer = data["choices"][0]["message"]["content"].strip()

                        if not is_classification_request:
                            dlg["messages"].append({"role": "assistant", "content": answer})
                            formatted_answer = format_markdown_to_html(answer)
                            await send_long_message_safe(message, formatted_answer, parse_mode='HTML')
                            if sheets_logger_instance:
                                user_name = message.from_user.full_name or f"User_{message.from_user.id}"
                                user_id = message.from_user.id
                                sheets_logger_instance.log_message(user_name, user_id, answer, is_user=False)

                        return answer
                    except Exception:
                        pass

                if attempt == max_retries - 1:
                    if not is_classification_request:
                        await message.answer(f"Извините, не удалось получить ответ от AI. Пожалуйста, попробуйте позже.")
                else:
                    await asyncio.sleep(2)
                    continue
            except Exception:
                if attempt == max_retries - 1:
                    if not is_classification_request:
                        await message.answer(f"Произошла ошибка. Пожалуйста, попробуйте позже.")
                else:
                    await asyncio.sleep(2)
                    continue

        if is_classification_request:
            return "ОБЩАЯ"
        elif is_complexity_classification:
            return "СЛОЖНЫЙ"
        else:
            await message.answer("Произошла ошибка при обработке вашего запроса.")
            return ""

    except Exception:
        if is_classification_request:
            return "ОБЩАЯ"
        elif is_complexity_classification:
            return "СЛОЖНЫЙ"
        else:
            await message.answer("Произошла ошибка при обработке запроса.")
            return ""