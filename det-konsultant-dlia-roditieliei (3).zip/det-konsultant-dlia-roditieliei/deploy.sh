#!/usr/bin/env bash

# Настройки окружения
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

# Путь к приватному ключу для SSH
KEY_FILE="$(pwd)/deploy_key"
# Внимание: для продакшена лучше добавить ключ хоста в ~/.ssh/known_hosts и убрать StrictHostKeyChecking=no
SSH_OPTS="-i $KEY_FILE -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

# Параметры подключения
REMOTE_USER="reynekefox"
REMOTE_HOST="89.169.163.167"
REMOTE_PATH="/home/reynekefox/det"

# Проверка утилит
echo "Found rsync: $(which rsync)"
echo "Found ssh: $(which ssh)"

# Синхронизация файлов на сервер
echo "📦 Обновляем файлы на сервере (rsync)..."
rsync -avz -e "ssh $SSH_OPTS" \
  --exclude '.git' \
  --exclude '__pycache__' \
  --exclude 'venv' \
  --exclude 'main_dev.py' \
  --exclude '.env' \
  --exclude 'deploy_key' \
  --exclude 'bot.log' \
  --exclude 'gcreds.json' \
  --exclude 'user_ids.json' \
  ./ $REMOTE_USER@$REMOTE_HOST:$REMOTE_PATH

# Перезапуск бота на сервере
echo "🚀 Перезапускаем бота на сервере..."
ssh $SSH_OPTS $REMOTE_USER@$REMOTE_HOST << EOF
set -e # Выйти немедленно, если какая-либо команда завершится неудачно.

# ПЕРЕХОДИМ В ДИРЕКТОРИЮ БОТА ПЕРЕД ВЫПОЛНЕНИЕМ ВСЕХ КОМАНД.
# Это гарантирует, что рабочая директория процесса бота будет правильной,
# и он сможет найти gcreds.json, .env и другие файлы.
cd "$REMOTE_PATH"

# Проверяем, запущен ли ваш конкретный бот, и останавливаем его, если да.
# Используем полный путь к main.py для точной идентификации процесса.
if pgrep -f "$REMOTE_PATH/main.py" > /dev/null; then
    echo "Останавливаем существующий процесс бота: $REMOTE_PATH/main.py..."
    pkill -f "$REMOTE_PATH/main.py"
    sleep 2
else
    echo "Основной бот не запущен, запускаем новый."
fi

# Проверяем и останавливаем heartbeat сервер
if pgrep -f "$REMOTE_PATH/heartbeat_server.py" > /dev/null; then
    echo "Останавливаем существующий heartbeat сервер: $REMOTE_PATH/heartbeat_server.py..."
    pkill -f "$REMOTE_PATH/heartbeat_server.py"
    sleep 2
else
    echo "Heartbeat сервер не запущен, запускаем новый."
fi

# Запускаем бота с помощью nohup
# Теперь он будет искать gcreds.json и другие файлы в текущей директории ($REMOTE_PATH)
nohup "$REMOTE_PATH/venv/bin/python" "$REMOTE_PATH/main.py" > "$REMOTE_PATH/bot.log" 2>&1 &
echo "Основной бот запущен в фоновом режиме."

# Запускаем heartbeat сервер
nohup "$REMOTE_PATH/venv/bin/python" "$REMOTE_PATH/heartbeat_server.py" > "$REMOTE_PATH/heartbeat.log" 2>&1 &
echo "Heartbeat сервер запущен в фоновом режиме."
EOF

# Завершение
echo "✅ Деплой завершён!"