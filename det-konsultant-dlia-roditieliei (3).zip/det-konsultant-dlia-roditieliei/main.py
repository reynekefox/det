import os
import logging
import asyncio
import signal
import sys

from aiogram import Bot, Dispatcher
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from dotenv import load_dotenv

# Импорты ваших модулей
from deepseek_handler import handle_deepseek_message, clear_user_dialog, add_message_to_deepseek_dialog
from sheets_logger import SheetsLogger
from docs_loader import DocsLoader
from user_manager import UserManager
from broadcaster import broadcast_command_handler

load_dotenv()

logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()])

logger = logging.getLogger(__name__)

try:
    docs_loader_instance = DocsLoader()
except Exception as e:
    logger.critical(f"Не удалось инициализировать DocsLoader: {e}. Бот не может работать без доступа к Google Docs.", exc_info=True)
    exit(1)

# Кешируем все инструкции при запуске
cached_prompts = {
    "main": "",
    "neurobos": ""
}

def load_all_prompts():
    """Загружает и кеширует все инструкции при запуске бота"""
    global cached_prompts

    # Загружаем основную инструкцию
    try:
        cached_prompts["main"] = docs_loader_instance.get_document_content()
    except Exception as e:
        logger.error(f"Ошибка загрузки основной инструкции: {e}")
        cached_prompts["main"] = docs_loader_instance._get_default_prompt()

    # Загружаем тематические инструкции
    for theme, doc_id in docs_loader_instance.thematic_doc_ids.items():
        try:
            cached_prompts[theme] = docs_loader_instance.get_document_content(doc_id)
        except Exception as e:
            logger.error(f"Ошибка загрузки тематической инструкции '{theme}': {e}")
            cached_prompts[theme] = ""


load_all_prompts()

try:
    sheets_logger_instance = SheetsLogger()
    sheets_logger_instance.create_headers_if_needed()
except Exception as e:
    logger.error(f"Не удалось инициализировать SheetsLogger: {e}. Логирование в Google Sheets будет недоступно.", exc_info=True)
    sheets_logger_instance = None

user_manager = UserManager()

ADMIN_IDS = [236147307, 214629016] # Ваш административный Telegram ID и новый админ


async def send_long_message(message: Message, text: str, parse_mode: str = None, chunk_size: int = 4000):
    for i in range(0, len(text), chunk_size):
        chunk = text[i:i + chunk_size]
        try:
            await message.answer(chunk, parse_mode=parse_mode)
        except Exception as e:
            logger.error(f"Ошибка при отправке части сообщения: {e}", exc_info=True)
            if parse_mode == 'HTML':
                await message.answer(chunk)

async def start_router(message: Message):
    user_manager.add_user(message.from_user.id)

    try:
        # Получаем реальное название бота для приветственного сообщения
        bot_name = await get_bot_info(message.bot)

        welcome_message = (
            f"👋 Привет! Я {bot_name} — ваш помощник по вопросам детского воспитания и мотивации. "
            "Я здесь, чтобы помочь родителям справиться с трудностями, связанными с воспитанием, "
            "обучением, мотивацией и дисциплиной, разобраться в причинах нежелания ребенка учиться, "
            "подобрать способы мотивации, подходящие именно вашему ребенку, найти подход к сложностям в поведении. \n\n"
            "Я могу: \n"
            "✨ Выдать подробный гайд по вашей проблеме.\n"
            "🛠️ Разработать стратегию и конкретные шаги по решению вашей проблемы с индивидуальными рекомендациями.\n"
            "📚 Сгенерировать для вас персональные идеи мотивирующих сказок или историй, которые помогут вашему ребенку понять ценность знаний в игровой форме.\n"
            "🎲 Предложить подборку развивающих игр, адаптированных под возраст вашего ребенка, которые сделают процесс обучения увлекательным.\n\n"
            "Расскажите, пожалуйста, с каким вопросом или проблемой вы столкнулись? И сколько лет вашему ребенку? 🤔"
        )
        await message.answer(welcome_message, parse_mode='HTML')

        user_id = message.from_user.id
        add_message_to_deepseek_dialog(user_id=user_id, role="assistant", content=welcome_message)

        if sheets_logger_instance:
            user_name = message.from_user.full_name or f"User_{message.from_user.id}"
            user_id = message.from_user.id
            sheets_logger_instance.log_message(user_name, user_id, "/start команда")

    except Exception as e:
        logger.error(f"Ошибка при обработке команды /start для пользователя {message.from_user.id}: {e}", exc_info=True)
        await message.answer("Произошла ошибка при обработке запроса. Пожалуйста, попробуйте позже.")

async def reset_dialog(message: Message):
    user_id = message.from_user.id
    user_name = message.from_user.full_name
    if clear_user_dialog(user_id):
        await message.answer("Ваша предыдущая переписка была удалена. Теперь мы можем начать заново!")
        if sheets_logger_instance:
            sheets_logger_instance.log_message(user_name, user_id, "/reset команда")
    else:
        await message.answer("У вас нет активной переписки для сброса.")

async def reload_prompts(message: Message):
    """Команда для обновления кешированных инструкций (только для админов)"""
    user_id = message.from_user.id

    if user_id not in ADMIN_IDS:
        await message.answer("У вас нет прав для использования этой команды.")
        return

    try:
        await message.answer("🔄 Обновляю кешированные инструкции...")
        load_all_prompts()
        await message.answer("✅ Кешированные инструкции успешно обновлены!")
    except Exception as e:
        logger.error(f"Ошибка при обновлении кешированных инструкций: {e}")
        await message.answer("❌ Произошла ошибка при обновлении инструкций.")

async def deepseek_router(message: Message):
    # Логируем получение сообщения с первыми 4 словами
    first_four_words = " ".join(message.text.split()[:4])
    logger.info(f"📩 Принято сообщение от пользователя {message.from_user.id}: '{first_four_words}...'")
    
    # Отправляем автоматический ответ "Дайте подумать..."
    await message.answer("Дайте подумать...")

    user_manager.add_user(message.from_user.id)

    if sheets_logger_instance:
        user_name = message.from_user.full_name or f"User_{message.from_user.id}"
        user_id = message.from_user.id
        sheets_logger_instance.log_message(user_name, user_id, message.text, is_user=True)

    # --- НОВАЯ ЛОГИКА ОПРЕДЕЛЕНИЯ ТЕМАТИКИ С ПОМОЩЬЮ DEEPSEEK ---
    user_id = message.from_user.id

    # Системный промпт для классификации
    classification_system_prompt = (
        "Ты - система классификации тем. Проанализируй контекст диалога и текущее сообщение пользователя, "
        "ответь ОДНИМ СЛОВОМ, какая тема в нем затрагивается. Возможные темы: 'НЕЙРОБОС', 'ДИСЦИПЛИНА', 'МОТИВАЦИЯ', 'ОБЩАЯ'. "
        "Учитывай контекст предыдущих сообщений. Если ни одна конкретная тема не подходит, ответь 'ОБЩАЯ'. "
        "Отвечай только одним словом, без лишних знаков препинания."
    )

    # Получаем историю диалога для контекста
    from deepseek_handler import dialogs
    dlg = dialogs.get(user_id, {"messages": []})

    # Берем последние 4 сообщения для контекста (2 пары вопрос-ответ)
    recent_messages = dlg["messages"][-4:] if len(dlg["messages"]) > 4 else dlg["messages"]

    # Добавляем текущее сообщение пользователя
    temp_messages_for_classification = recent_messages + [{"role": "user", "content": message.text}]

    detected_topic = "ОБЩАЯ" # Дефолтное значение
    try:
        # Временный запрос к DeepSeek для классификации
        classification_response = await handle_deepseek_message(
            message=message,
            system_prompt_content=classification_system_prompt,
            sheets_logger_instance=None, # Не логируем этот промежуточный запрос в Sheets
            is_classification_request=True,
            dialog_history_override=temp_messages_for_classification, # Передаем только сообщение пользователя
            max_tokens_override=10 # Ограничиваем ответ DeepSeek 10 токенами
        )

        detected_topic = classification_response.strip().upper() # Приводим к верхнему регистру для сравнения

    except Exception as e:
        detected_topic = "ОБЩАЯ" # В случае ошибки, считаем тему общей

    # Проверяем, есть ли специальная тематическая инструкция
    if detected_topic == "НЕЙРОБОС" and cached_prompts.get("neurobos"):
        final_system_prompt_content = cached_prompts["neurobos"]
    else:
        final_system_prompt_content = cached_prompts["main"]

    # Передаем динамически сформированный системный промпт
    await handle_deepseek_message(message, final_system_prompt_content, sheets_logger_instance)

async def get_bot_info(bot: Bot):
    """Получает информацию о боте и возвращает его имя."""
    bot_info = await bot.get_me()
    return bot_info.first_name

async def main():
    token = os.getenv("TELEGRAM_TOKEN")
    if not token:
        logger.critical("TELEGRAM_TOKEN не установлен в переменных окружения! Бот не может быть запущен.")
        return

    bot = Bot(token=token)
    dp = Dispatcher()

    # Получаем реальное имя бота для логов
    try:
        bot_info = await bot.get_me()
        bot_name = bot_info.first_name
        print(f"🤖 Запускается {bot_name}...")
    except Exception as e:
        bot_name = "ИИ-помощник"
        print(f"🤖 Запускается {bot_name}... (не удалось получить имя: {e})")

    dp.message.register(start_router, CommandStart())
    dp.message.register(reset_dialog, Command("reset"))
    dp.message.register(reload_prompts, Command("reload_prompts"))
    dp.message.register(broadcast_command_handler, Command("broadcast"))
    dp.message.register(deepseek_router)

    dp.workflow_data.update({
        "sheets_logger_instance": sheets_logger_instance,
        "user_manager": user_manager,
        "ADMIN_IDS": ADMIN_IDS,
    })

    # Обработка сигналов для graceful shutdown
    shutdown_event = asyncio.Event()

    def signal_handler():
        shutdown_event.set()

    # Регистрируем обработчики сигналов
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, signal_handler)

    try:
        print("✅ Бот успешно запущен и готов к работе!")
        print(f"📝 Название: {bot_name}")

        # Создаем задачу для polling
        polling_task = asyncio.create_task(dp.start_polling(bot, skip_updates=True))

        # Ждем либо завершения polling, либо сигнала остановки
        done, pending = await asyncio.wait(
            [polling_task, asyncio.create_task(shutdown_event.wait())],
            return_when=asyncio.FIRST_COMPLETED
        )

        # Если получили сигнал остановки
        if shutdown_event.is_set():
            polling_task.cancel()
            try:
                await polling_task
            except asyncio.CancelledError:
                pass

        # Отменяем оставшиеся задачи
        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    except Exception as e:
        logger.error(f"Ошибка в основном цикле: {e}", exc_info=True)
    finally:
        # Сохраняем данные пользователей
        try:
            user_manager.save_user_ids()
        except Exception as e:
            logger.error(f"Ошибка при сохранении данных пользователей: {e}")

        # Закрываем сессию бота
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.critical(f"Критическая ошибка в главном цикле бота: {e}", exc_info=True)